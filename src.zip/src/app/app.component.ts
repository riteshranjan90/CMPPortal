import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'angulardatatable';
  dynamicdata: any = [];
  Object: any;
  colmundata : any
  constructor(private http: HttpClient){    
    this.http.get('http://localhost:8080/sqleditor/sql').subscribe(data => {        
      this.dynamicdata = data;
        setTimeout(()=>{   
          $('#dataTables-example').DataTable( {
            data: JSON.parse(this.dynamicdata).data,
            columns: JSON.parse(this.dynamicdata).columns,
            pagingType: 'full_numbers',
            pageLength: 2,
            processing: true,
            lengthMenu : [2,5, 10, 25],
            dom: 'Rlfrtip',
            drawCallback: () => {
              $('.paginate_button.next').on('click', () => {
                  this.nextButtonClickEvent();
                });
            }
        } );
        }, 1);
     }, error => console.error(error));
  }
   
    ngOnInit() {     
      $('.dateadded').on( 'change', function (ret :any) {
        var v = ret.target.value  // getting search input value        
        $('#dataTables-example').DataTable().columns(3).search(v).draw();
      });
    }

    buttonInRowClick(event: any): void {
      event.stopPropagation();
      console.log('Button in the row clicked.');
    }
  
    wholeRowClick(): void {
      console.log('Whole row clicked.');
    }
  
    nextButtonClickEvent(): void {
      //do next particular records like  101 - 200 rows.
      //we are calling to api
  
      console.log('next clicked')
    }
    previousButtonClickEvent(): void {
      //do previous particular the records like  0 - 100 rows.
      //we are calling to API
    }
}
