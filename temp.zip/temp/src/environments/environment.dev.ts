export const environment = {
    production: false,
    title: 'Dev Environment Heading',
    apiURL: 'http://localhost:8080'
  };