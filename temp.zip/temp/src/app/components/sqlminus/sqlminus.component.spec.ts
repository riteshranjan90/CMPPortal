import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SqlminusComponent } from './sqlminus.component';

describe('SqlminusComponent', () => {
  let component: SqlminusComponent;
  let fixture: ComponentFixture<SqlminusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SqlminusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SqlminusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
