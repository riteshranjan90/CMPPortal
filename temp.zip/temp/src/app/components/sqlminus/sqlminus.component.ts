import { Component, OnInit } from '@angular/core';
import { RestApiService } from "../../shared/rest-api.service";

declare var DataTable: any;

@Component({
  selector: 'app-sqlminus',
  templateUrl: './sqlminus.component.html',
  styleUrls: ['./sqlminus.component.scss']
})
export class SqlminusComponent implements OnInit {
  
  constructor(private restApiService : RestApiService) { 
    this.restApiService = restApiService;
  }

  ngOnInit(): void {
    this.getSqlMinusQuery();
    (function ($) {
      $(document).ready(function(){
        console.log("Hello from jQuery!");
        $('#example').DataTable( {
          "scrollX": true
        });
      });
    })(DataTable);
  }

  getSqlMinusQuery() {
    return this.restApiService.getSqlMinusQuery().subscribe((res: {}) => {
      console.log(res) ;
    })
  }

}
