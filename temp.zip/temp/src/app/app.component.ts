import { Component,OnInit } from '@angular/core';
import { environment } from '../environments/environment';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'CMPPortal';
  apiURL = environment.apiURL;
  ngOnInit() {
    /*const body = <HTMLDivElement> document.body;
    const script = document.createElement('script');
    script.innerHTML = '';
    script.src = '../assets/js/jquery.dataTables.min.js';
    script.async = false;
    script.defer = true;
    body.appendChild(script);*/
  }
 }
